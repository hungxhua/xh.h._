﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace _20230329WebQuiz_09131345.Models.Attendance
{
    public class Attendance
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        [Required]
        public string ClassCode { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        [Required]
        public string SubjectCode { get; set; }
        public int ID { get; set; }

        [Column(TypeName = "nvarchar(250)")]
        [StringLength(60, MinimumLength = 3)]
        [Required]
        public string Name { get; set; }

        [DataType(DataType.Date)]
        [Column(TypeName = "Date")]
        public DateTime ClassDate { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        [Required]
        public string Absent { get; set; }

    }
}
