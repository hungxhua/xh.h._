﻿using Microsoft.EntityFrameworkCore;

namespace _20230329WebQuiz_09131345.Models.Attendance
{
    public class AttendanceDbContext:DbContext
    {
        public AttendanceDbContext(DbContextOptions<AttendanceDbContext> options)
        : base(options)
        {
            
        }


        public DbSet<Attendance> attendance_09131345 { get; set; }
    }
}
