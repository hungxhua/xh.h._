﻿using Microsoft.EntityFrameworkCore;

namespace _20230329WebQuiz_09131345.Models.Book
{
    public class BookDbContext:DbContext
    {
        public BookDbContext(DbContextOptions<BookDbContext> options)
        : base(options)
        {
            
        }
        public DbSet<Book> books_09131345 { get; set; }
    }
}
