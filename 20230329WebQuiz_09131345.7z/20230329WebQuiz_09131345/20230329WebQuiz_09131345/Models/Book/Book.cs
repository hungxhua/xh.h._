﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace _20230329WebQuiz_09131345.Models.Book
{
    public class Book
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        [Required]
        public string Subject { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        [Required]
        public string Title { get; set; }
        public int ID { get; set; }

        [Column(TypeName = "nvarchar(250)")]
        [StringLength(60, MinimumLength = 3)]
        [Required]
        public string Name { get; set; }

        [DataType(DataType.Date)]
        [Column(TypeName = "Date")]
        public DateTime OrderDate { get; set; }

    }
}
