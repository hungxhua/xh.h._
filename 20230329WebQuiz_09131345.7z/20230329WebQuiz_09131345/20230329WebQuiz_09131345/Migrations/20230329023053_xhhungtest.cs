﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace _20230329WebQuiz_09131345.Migrations
{
    /// <inheritdoc />
    public partial class xhhungtest : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
