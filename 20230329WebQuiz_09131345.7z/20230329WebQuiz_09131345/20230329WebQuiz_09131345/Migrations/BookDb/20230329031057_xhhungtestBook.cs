﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace _20230329WebQuiz_09131345.Migrations.BookDb
{
    /// <inheritdoc />
    public partial class xhhungtestBook : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
