﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace _20230329WebQuiz_09131345.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "attendance_09131345",
                columns: table => new
                {
                    ClassCode = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    SubjectCode = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    ID = table.Column<int>(type: "int", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(60)", maxLength: 60, nullable: false),
                    ClassDate = table.Column<DateTime>(type: "Date", nullable: false),
                    Absent = table.Column<string>(type: "nvarchar(50)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_attendance_09131345", x => x.ClassCode);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "attendance_09131345");
        }
    }
}
