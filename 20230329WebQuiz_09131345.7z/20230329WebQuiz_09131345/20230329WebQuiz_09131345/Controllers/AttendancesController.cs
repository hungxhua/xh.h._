﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using _20230329WebQuiz_09131345.Models.Attendance;

namespace _20230329WebQuiz_09131345.Controllers
{
    public class AttendancesController : Controller
    {
        private readonly AttendanceDbContext _context;

        public AttendancesController(AttendanceDbContext context)
        {
            _context = context;
        }

        // GET: Attendances
        public async Task<IActionResult> Index()
        {
              return _context.attendance_09131345 != null ? 
                          View(await _context.attendance_09131345.ToListAsync()) :
                          Problem("Entity set 'AttendanceDbContext.attendance_09131345'  is null.");
        }

        // GET: Attendances/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null || _context.attendance_09131345 == null)
            {
                return NotFound();
            }

            var attendance = await _context.attendance_09131345
                .FirstOrDefaultAsync(m => m.ClassCode == id);
            if (attendance == null)
            {
                return NotFound();
            }

            return View(attendance);
        }

        // GET: Attendances/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Attendances/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ClassCode,SubjectCode,ID,Name,ClassDate,Absent")] Attendance attendance)
        {
            if (ModelState.IsValid)
            {
                _context.Add(attendance);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(attendance);
        }

        // GET: Attendances/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null || _context.attendance_09131345 == null)
            {
                return NotFound();
            }

            var attendance = await _context.attendance_09131345.FindAsync(id);
            if (attendance == null)
            {
                return NotFound();
            }
            return View(attendance);
        }

        // POST: Attendances/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("ClassCode,SubjectCode,ID,Name,ClassDate,Absent")] Attendance attendance)
        {
            if (id != attendance.ClassCode)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(attendance);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AttendanceExists(attendance.ClassCode))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(attendance);
        }

        // GET: Attendances/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null || _context.attendance_09131345 == null)
            {
                return NotFound();
            }

            var attendance = await _context.attendance_09131345
                .FirstOrDefaultAsync(m => m.ClassCode == id);
            if (attendance == null)
            {
                return NotFound();
            }

            return View(attendance);
        }

        // POST: Attendances/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            if (_context.attendance_09131345 == null)
            {
                return Problem("Entity set 'AttendanceDbContext.attendance_09131345'  is null.");
            }
            var attendance = await _context.attendance_09131345.FindAsync(id);
            if (attendance != null)
            {
                _context.attendance_09131345.Remove(attendance);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AttendanceExists(string id)
        {
          return (_context.attendance_09131345?.Any(e => e.ClassCode == id)).GetValueOrDefault();
        }
    }
}
